﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveInvaders : MonoBehaviour
{
    float velocity = 2.0f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(velocity * Time.deltaTime, 0.0f, 0.0f);
        if (velocity > 0.0f && transform.position.x > 3.5f)
        {
            velocity = -velocity;
            transform.Translate(0.0f, -0.75f, 0.0f);
        }
        if (velocity < 0.0f && transform.position.x < -3.5f)
        {
            velocity = -velocity;
            transform.Translate(0.0f, -0.75f, 0.0f);
        }
    }
}
