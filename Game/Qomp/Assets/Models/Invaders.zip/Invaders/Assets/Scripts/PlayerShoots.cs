﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoots : MonoBehaviour
{
    public GameObject shotObj;
    public float shotsPerSecond = 2.0f;
    public float speed = 15.0f;

    public AudioClip shotSound;

    float timeFromPreviousShot;

    // Start is called before the first frame update
    void Start()
    {
        timeFromPreviousShot = 0.0f;
    }

    // Update is called once per frame
    void Update()
    {
        timeFromPreviousShot += Time.deltaTime;
        if (Input.GetKey(KeyCode.Space) && timeFromPreviousShot > (1.0f / shotsPerSecond))
        {
            AudioSource.PlayClipAtPoint(shotSound, new Vector3(0.0f, 0.0f, -10.0f));
            timeFromPreviousShot = 0.0f;
            GameObject obj = (GameObject)Instantiate(shotObj, transform.position + new Vector3(0.0f, 1.0f, 0.0f), transform.rotation);
            obj.GetComponent<Rigidbody>().velocity = new Vector3(0.0f, speed, 0.0f);
        }
    }
}
